import XCTest
@testable import LibITR_ForDistribution

final class LibITR_ForDistributionTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(LibITR_ForDistribution().text, "Hello, World!")
    }
}
