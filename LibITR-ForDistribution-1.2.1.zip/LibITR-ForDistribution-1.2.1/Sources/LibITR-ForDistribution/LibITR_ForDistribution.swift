public struct LibITR_ForDistribution {
    public private(set) var text = "Hello, World!!"

    public init() {
    }
}
